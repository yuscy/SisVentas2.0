<?php

declare(strict_types=1);

namespace Termwind\Components;

final class Dd extends Element
{
    protected static array $defaultStyles = ['block', 'ml-4'];
}
